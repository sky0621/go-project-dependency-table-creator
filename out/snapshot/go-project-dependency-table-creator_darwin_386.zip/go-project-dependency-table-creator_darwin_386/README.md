# go-project-dependency-table-creator

## You need ...

### ・go (ver1.7)

### ・git

## How to use

### ・do [ $glide up ]

### ・do [ $go run main.go -t 【プロジェクト群の親ディレクトリフルパス】 -d 【glide.yaml内で探索する依存プロジェクトのドメイン】 ]
